"""Quotes register (pair B) · TEMPORARY STAND-IN made by pair A for step 4,
following pair B's interfaces-S3-pairB.txt, EXCEPT record_quote: as agreed in
pair A's final file, the register issues the reference, so record_quote is not
given one and answers it. Pair B's block for record_quote must say the same.
Replace it with pair B's own stub file when they hand it over."""
from datetime import datetime
from decimal import Decimal


class QuotesRegister:
    def record_quote(self, unit_id, price_per_kwh, fixed_fees, tariff, valid_until):
        """Answers the reference it issued ("Q-" and 4 digits); None if it cannot be recorded."""
        return "Q-0001"

    def find_quote(self, reference):
        """Answers the quote with that reference, even if expired; None if there is none."""
        return {"reference": "Q-0001", "unit_id": "U3", "price_per_kwh": Decimal("0.45"),
                "fixed_fees": Decimal("1.00"), "tariff": "site standard",
                "valid_until": datetime(2026, 10, 5, 13, 45)}
