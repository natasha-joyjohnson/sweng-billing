"""Tariff book (pair B) · TEMPORARY STAND-IN made by pair A for step 4,
following pair B's interfaces-S3-pairB.txt (names, inputs, stub answers).
Replace it with pair B's own stub file when they hand it over."""
from decimal import Decimal


class TariffBook:
    def set_rule(self, rule, valid_from):
        """Answers True when recorded; False if the rule is not "site wins" or "campaign wins"."""
        return True

    def add_tariff(self, unit_id, kind, name, price_per_kwh, fixed_fee, valid_from, valid_until):
        """Answers True when recorded; False if the kind is wrong or a price is negative."""
        return True

    def prices_for(self, unit_id, time):
        """Answers the site and campaign prices and which applies; a unit with no tariff then: None."""
        return {"site": {"name": "site standard", "price_per_kwh": Decimal("0.45"),
                         "fixed_fee": Decimal("1.00")},
                "campaign": None, "applies": "site"}
