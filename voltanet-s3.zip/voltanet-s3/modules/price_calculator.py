"""Price calculator (pair B) · TEMPORARY STAND-IN made by pair A for step 4,
following pair B's interfaces-S3-pairB.txt (names, inputs, stub answers).
Replace it with pair B's own stub file when they hand it over."""
from decimal import Decimal


class PriceCalculator:
    def amount(self, price_per_kwh, energy_kwh, fixed_fees):
        """Answers energy x price + fees in euros, to the cent; None if energy is None or a value is negative."""
        return Decimal("9.28")
